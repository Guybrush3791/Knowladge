package it.nations;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {

	private final static String DB_URL = "jdbc:mysql://localhost:3306/nation";
	private final static String DB_USER = "root";
	private final static String DB_PASSWORD = "rootpassword";
	private final static String FORMAT_TABLE = "%4s%40s%30s%20s\n";
	
	private final static String QUERY = "SELECT cy.name , cy.country_id, r.name , ct.name "
			+ "FROM countries cy "
			+ "JOIN regions r ON cy.region_id = r.region_id "
			+ "JOIN continents ct ON r.continent_id = ct.continent_id "
			+ "WHERE cy.name LIKE ? "
			+ "ORDER BY cy.name";
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Search: ");
		String search = scan.nextLine();
		
		try(Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)){
			 
			try(PreparedStatement ps = con.prepareStatement(QUERY)){
				ps.setString(1, "%" + search + "%");
				
				try(ResultSet rs = ps.executeQuery()){
					if(rs.next()) {
						System.out.format(FORMAT_TABLE, "ID", "COUNTRY", "REGION", "CONTINENT");
						
						do {
							String name = rs.getString(1);
							int countryId = rs.getInt(2);
							String regionName = rs.getString(3);
							String continentName = rs.getString(4);
							
	
							System.out.format(FORMAT_TABLE, countryId, name, regionName, continentName);
							
						} while(rs.next());
					} else {
						System.out.println("No matches found");
					}
				}
			}
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
		
		scan.close();
	}
}
