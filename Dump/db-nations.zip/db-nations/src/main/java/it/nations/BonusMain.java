package it.nations;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class BonusMain {

	private final static String DB_URL = "jdbc:mysql://localhost:3306/nation";
	private final static String DB_USER = "root";
	private final static String DB_PASSWORD = "rootpassword";
	
	private final static String FORMAT_TABLE = "%4s%40s%30s%20s\n";
	
	private final static String QUERY_COUNTRIES = "SELECT cy.name , cy.country_id, r.name , ct.name "
			+ "FROM countries cy "
			+ "JOIN regions r ON cy.region_id = r.region_id "
			+ "JOIN continents ct ON r.continent_id = ct.continent_id "
			+ "WHERE cy.name LIKE ? "
			+ "ORDER BY cy.name";
	
	private final static String QUERY_LANGUAGES = "SELECT l.`language` "
			+ "FROM country_languages cl "
			+ "JOIN languages l ON cl.language_id = l.language_id "
			+ "WHERE cl.country_id = ?;";
	
	private final static String QUERY_COUNTRY_STATS = "SElECT year, population, gdp \n"
			+ "FROM country_stats "
			+ "WHERE country_id = ? "
			+ "ORDER BY `year` DESC "
			+ "LIMIT 1;";
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		

		
		System.out.print("Search: ");
		String search = scan.nextLine();
		
		try(Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)){
			
			Map<Integer, String> results = new HashMap<Integer, String>();
			
			try(PreparedStatement ps = con.prepareStatement(QUERY_COUNTRIES)){
				ps.setString(1, "%" + search + "%");
				
				try(ResultSet rs = ps.executeQuery()){
					if(rs.next()) {
						
						System.out.format(FORMAT_TABLE, "ID", "COUNTRY", "REGION", "CONTINENT");
						
						do {
							String name = rs.getString(1);
							int countryId = rs.getInt(2);
							String regionName = rs.getString(3);
							String continentName = rs.getString(4);
			
							System.out.format(FORMAT_TABLE, countryId, name, regionName, continentName);
							results.put(countryId, name);
							
						} while(rs.next());
						
						
					} else {
						System.out.println("No matches found");
					}
					
				}

				
		
			}
			
			if(results.size() > 0) {
				System.out.print("Choose a country id: ");
				int searchId = Integer.parseInt(scan.nextLine());
				
				if(results.containsKey(searchId)){
					System.out.println("\nDetails for country: " + results.get(searchId));
					
					List<String> languages = new ArrayList<String>();
					int year = 0;
					int population = 0;
					BigDecimal gdp = null;
					
					
					try(PreparedStatement psLang = con.prepareStatement(QUERY_LANGUAGES)){
						psLang.setInt(1, searchId);
						try(ResultSet rsLang = psLang.executeQuery()){
							while(rsLang.next()) {
								languages.add(rsLang.getString(1));
							}
						}
					}
					try(PreparedStatement psStats = con.prepareStatement(QUERY_COUNTRY_STATS)){
						psStats.setInt(1, searchId);
						try(ResultSet rsStats = psStats.executeQuery()){
							if(rsStats.next()) {
								year = rsStats.getInt(1);
								population = rsStats.getInt(2);
								gdp = rsStats.getBigDecimal(3);
							}
						}
					}
					
					System.out.print("Languages: ");
					if(languages.size() > 0) {
						String langString = "";
						for(String l : languages) {
							langString += l + ", ";
						}
						System.out.println(langString.substring(0, langString.length()-2));
						
					} else {
						System.out.println("Not known");
					}
					System.out.println("Most recent stats");
					if(year > 0) {
						System.out.println("Year: " + year);
						System.out.println("Population: " + population);
						System.out.println("GDP: " + gdp.toString());
					} else {
						System.out.println("Not known");
					}
				} else {
					System.out.println("Invalid id");
				}
				
				
			}
			
			
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
		
		scan.close();
	}
	
}
